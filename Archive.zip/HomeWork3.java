package com.auto.germeny;

public class HomeWork3 {
    public static void main(String[] args) {

        int a = 637;
        // переводим число 637 из 10 -> 3

        System.out.println(a / 3);      // 212
        System.out.println(a % 3);          // 1

        System.out.println(212 / 3);    // 70
        System.out.println(212 % 3);        // 2

        System.out.println(70 / 3);    // 23
        System.out.println(70 % 3);        // 1

        System.out.println(23 / 3);     // 7
        System.out.println(23 % 3);         // 2

        System.out.println(7 / 3);     // 2
        System.out.println(7 % 3);         // 1

        System.out.println(2 / 3);     // 0
        System.out.println(2 % 3);         // 2

       // 212121
    }
}
