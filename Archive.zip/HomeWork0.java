package com.auto.germeny;

public class HomeWork0 {
    public static void main(String[] args) {
        //  DECIMAL
        int a = 365;
        System.out.println(3*100 + 6*10 + 5);
        System.out.println(3*Math.pow(10,2) + 6*Math.pow(10,1) + 5*Math.pow(10,0));

    }
}
