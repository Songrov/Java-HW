package com.auto;

public class HomeWork2 {
    public static void main(String[] args) {
        int a = 637;
        // переводим число 637 из 10 -> 2

        System.out.println(a / 2);      // 318
        System.out.println(a % 2);          // 1

        System.out.println(318 / 2);    // 159
        System.out.println(318 % 2);        // 0

        System.out.println(159 / 2);    // 79
        System.out.println(159 % 2);        // 1

        System.out.println(79 / 2);     // 39
        System.out.println(79 % 2);         // 1

        System.out.println(39 / 2);     // 19
        System.out.println(39 % 2);         // 1

        System.out.println(19 / 2);     // 9
        System.out.println(19 % 2);         // 1

        System.out.println(9 / 2);      // 4
        System.out.println(9 % 2);          // 1

        System.out.println(4 / 2);      // 2
        System.out.println(4 % 2);          // 0

        System.out.println(2 / 2);      // 1
        System.out.println(2 % 2);          // 0

        System.out.println(1 / 2);        // 0
        System.out.println(1 % 2);            // 1

        //  1001111101
    }
}
