package com.auto;

public class HomeWork {
    public static void main(String[] args) {

        //indexes  76543210
        int a2 = 0b11100111;

        //переводим число 11100111 из 2 -> 10

        System.out.println(a2);

        System.out.println(1 * Math.pow(2, 7) + 1 * Math.pow(2, 6) + 1 * Math.pow(2, 5) + 1 * Math.pow(2, 2) + 1 * Math.pow(2, 1) + 1 * Math.pow(2, 0));


    }
}
